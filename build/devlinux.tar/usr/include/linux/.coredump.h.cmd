savedcmd_usr/include/linux/coredump.h := sh ./scripts/headers_install.sh include/uapi/linux/coredump.h usr/include/linux/coredump.h
