savedcmd_usr/include/misc/amd-apml.h := sh ./scripts/headers_install.sh include/uapi/misc/amd-apml.h usr/include/misc/amd-apml.h
