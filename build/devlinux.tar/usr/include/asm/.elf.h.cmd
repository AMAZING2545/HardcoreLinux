savedcmd_usr/include/asm/elf.h := sh ./scripts/headers_install.sh arch/x86/include/uapi/asm/elf.h usr/include/asm/elf.h
