savedcmd_usr/include/asm/setup_data.h := sh ./scripts/headers_install.sh arch/x86/include/uapi/asm/setup_data.h usr/include/asm/setup_data.h
