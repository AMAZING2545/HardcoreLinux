#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "popt" for configuration "Release"
set_property(TARGET popt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(popt PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-musl/libpopt.so.1.19"
  IMPORTED_SONAME_RELEASE "libpopt.so.0"
  )

list(APPEND _cmake_import_check_targets popt )
list(APPEND _cmake_import_check_files_for_popt "${_IMPORT_PREFIX}/lib/x86_64-linux-musl/libpopt.so.1.19" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
