savedcmd_usr/include/drm/ethosu_accel.h := sh ./scripts/headers_install.sh include/uapi/drm/ethosu_accel.h usr/include/drm/ethosu_accel.h
