savedcmd_usr/include/drm/amdxdna_accel.h := sh ./scripts/headers_install.sh include/uapi/drm/amdxdna_accel.h usr/include/drm/amdxdna_accel.h
