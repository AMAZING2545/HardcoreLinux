savedcmd_usr/include/drm/rocket_accel.h := sh ./scripts/headers_install.sh include/uapi/drm/rocket_accel.h usr/include/drm/rocket_accel.h
