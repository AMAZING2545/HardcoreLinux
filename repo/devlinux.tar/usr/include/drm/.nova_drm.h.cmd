savedcmd_usr/include/drm/nova_drm.h := sh ./scripts/headers_install.sh include/uapi/drm/nova_drm.h usr/include/drm/nova_drm.h
