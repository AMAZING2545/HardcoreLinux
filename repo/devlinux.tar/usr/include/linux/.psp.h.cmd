savedcmd_usr/include/linux/psp.h := sh ./scripts/headers_install.sh include/uapi/linux/psp.h usr/include/linux/psp.h
