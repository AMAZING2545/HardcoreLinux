savedcmd_usr/include/linux/pps_gen.h := sh ./scripts/headers_install.sh include/uapi/linux/pps_gen.h usr/include/linux/pps_gen.h
