savedcmd_usr/include/linux/gpib_ioctl.h := sh ./scripts/headers_install.sh include/uapi/linux/gpib_ioctl.h usr/include/linux/gpib_ioctl.h
