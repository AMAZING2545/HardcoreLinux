savedcmd_usr/include/linux/ethtool_netlink_generated.h := sh ./scripts/headers_install.sh include/uapi/linux/ethtool_netlink_generated.h usr/include/linux/ethtool_netlink_generated.h
