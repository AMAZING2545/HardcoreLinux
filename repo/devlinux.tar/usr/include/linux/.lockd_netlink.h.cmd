savedcmd_usr/include/linux/lockd_netlink.h := sh ./scripts/headers_install.sh include/uapi/linux/lockd_netlink.h usr/include/linux/lockd_netlink.h
