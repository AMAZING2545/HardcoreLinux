savedcmd_usr/include/fwctl/bnxt.h := sh ./scripts/headers_install.sh include/uapi/fwctl/bnxt.h usr/include/fwctl/bnxt.h
