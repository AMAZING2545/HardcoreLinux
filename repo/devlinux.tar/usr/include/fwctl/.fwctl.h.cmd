savedcmd_usr/include/fwctl/fwctl.h := sh ./scripts/headers_install.sh include/uapi/fwctl/fwctl.h usr/include/fwctl/fwctl.h
