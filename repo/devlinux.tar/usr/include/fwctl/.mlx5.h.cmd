savedcmd_usr/include/fwctl/mlx5.h := sh ./scripts/headers_install.sh include/uapi/fwctl/mlx5.h usr/include/fwctl/mlx5.h
