savedcmd_usr/include/fwctl/pds.h := sh ./scripts/headers_install.sh include/uapi/fwctl/pds.h usr/include/fwctl/pds.h
